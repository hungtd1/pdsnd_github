Ref:
https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.mode.html
https://stackoverflow.com/questions/23178129/getting-min-and-max-dates-from-a-pandas-dataframe
https://www.geeksforgeeks.org/python-pandas-dataframe-mean/